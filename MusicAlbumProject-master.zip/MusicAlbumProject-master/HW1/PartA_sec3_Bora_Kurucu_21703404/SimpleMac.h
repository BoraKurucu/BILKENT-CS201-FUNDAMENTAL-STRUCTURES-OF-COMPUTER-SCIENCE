    #ifndef __SIMPLE_MAC_H
    #define __SIMPLE_MAC_H
    #include <string>
    using namespace std;
    #include "SimpleMusicAlbum.h"
    class MAC{
    public:
     MAC();
     ~MAC();
     MAC(const MAC &macToCopy);
     void operator=(const MAC &right);
     bool addMusicAlbum(const string maArtist,
     const string maTitle,
    const int maYear);
     bool removeMusicAlbum(const string maArtist,
     const string maTitle);
     int getMusicAlbums(MusicAlbum *&allMusicAlbums);
     bool albumExist(string maArtist,string maTitle,int &indexFinder);
    private:
     MusicAlbum *musicAlbums;
     int noOfMusicAlbums;
    };
    #endif
